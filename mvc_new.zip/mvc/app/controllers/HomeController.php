<?php

class HomeController extends Controller {
    public function index() {
        $cate = Category::all();
        $this->render('layouts/home', ['cate'=>$cate]);
    }
    public function list() {
        echo "danh sách trang";
    }

    function update($id) {
        $arr = ['cate_name'=>"Samsung", 'slug'=>"sam-sung", 'desc'=>'Điện thoại samsung siêu đắt'];
        $cate = new Category;
        echo $cate->update($arr, $id);        
    }
}