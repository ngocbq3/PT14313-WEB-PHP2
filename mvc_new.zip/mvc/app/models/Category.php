<?php

class Category extends BaseModel {
    public $tableName = 'categories';
}