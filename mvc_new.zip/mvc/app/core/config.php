<?php

define("BASE_URL", "http://localhost/pt14313-web-php2/mvc/");