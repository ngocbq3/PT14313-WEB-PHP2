<style>
    nav {
        width: 900px;
        margin: auto;
        height: 40px;
        background: green;
        line-height: 40px;
    }
    nav ul li{
        display: inline-block;
    }
    nav ul li a{
        display: block;
        padding: 0 10px;
        color: #fff;
        text-decoration: none;
    }
</style>
<h1>Trang chủ</h1>
<?php

$cate = $data['cate'];
?>
<nav>
    <ul>
       <?php foreach($cate as $c) : ?>
            <li><a href="./category/list/<?=$c->id?>"><?=$c->cate_name?></a></li>
        <?php endforeach; ?>
    </ul>
</nav>
