<?php
$products = $data['products'];
?>
<?php foreach($products as $p) : ?>
    <h2><?=$p->name?></h2>
    <p><?=$p->detail?></p>
<?php endforeach; ?>